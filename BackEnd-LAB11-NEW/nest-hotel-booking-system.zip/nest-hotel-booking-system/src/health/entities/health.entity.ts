export class Health {}
