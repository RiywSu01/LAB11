export class CreateHealthDto {}
